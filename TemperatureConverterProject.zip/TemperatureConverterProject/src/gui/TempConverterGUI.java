package gui;

import converter.TempConverterBean;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TempConverterGUI extends JFrame {

    private JTextField inputField;
    private JComboBox<String> conversionBox;
    private JButton convertButton;
    private JLabel resultLabel;

    public TempConverterGUI() {
        setTitle("Temperature Converter");
        setSize(400, 200);
        
setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 10));
        // Input
        add(new JLabel("Enter Temperature:"));
        inputField = new JTextField();
        add(inputField);   
        // Conversion type
        add(new JLabel("Convert to:"));
        String[] options = {"Celsius to Fahrenheit", "Fahrenheit to Celsius"};
        conversionBox = new JComboBox<>(options);
        add(conversionBox);
        // Convert button  
        convertButton = new JButton("Convert");
        add(convertButton);
        // Result label
        resultLabel = new JLabel("Result: ");
        add(resultLabel);
        //Button action
        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { 
            convertTemperature();
            }
        });
        setVisible(true);
    }
    private void convertTemperature() {
        try {
            double inputTemp = 
            Double.parseDouble(inputField.getText());
            TempConverterBean converter = new TempConverterBean();
            double result;

            if (conversionBox.getSelectedItem().equals("Celsius to Fahrenheit")) {
                converter.setCelsius(inputTemp);
                result = converter.toFahrenheit();
            } else {
                converter.setFahrenheit(inputTemp);
                result = converter.toCelsius();
            }
            resultLabel.setText("Result: " + result);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number.");
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TempConverterGUI());
    }
}
            