package converter;
public class TempConverterBean {
    private double celsius;
    private double fahrenheit;

    public void setCelsius(double celsius) {
        this.celsius = celsius;
    }
    public double getCelsius() {
        return celsius;
    }

    public void setFahrenheit(double fahrenheit) {
        this.fahrenheit = fahrenheit;
    }
    public double getFahrenheit() {
        return fahrenheit;
    }
    public double toFahrenheit() {
        return (celsius * 9 / 5) + 32;
    }
    public double toCelsius() {
        return (fahrenheit - 32) * 5 / 9;
    }
}